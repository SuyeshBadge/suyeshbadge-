 
 <?php include_once("./includes/header.php"); ?>
  <?php include_once('connect.php') ?>



  <div class="row">
      <div class="mx-auto" id="contact">
          <div class="container1" style="padding-top: 25%;">
            <div class="card newscards bg-light sr-contact-1"  >
            <div class="cal">   
                <h1>Contact Us</h1>
            </div>
            <article class="card-body mx-auto" style="max-width: 500px;">
                    <form method="post" action="contact.php" >

                      <div class="form-group input-group">
                         <div class="input-group-prepend">
                            <span class="input-group-text"> <i class="fa fa-user"></i> </span>
                         </div>
                            <input name="name" id='name' class="form-control" required="required" pattern="[a-zA-Z\s]+" placeholder="Full name" type="text">
                      </div> 
                        <!-- form-group// -->
                        <div class="form-group input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
                            </div>
                            <input name="email" id='email' class="form-control" required="required" placeholder="Email address" type="email">
                        </div> 
                        <!-- form-group// -->
                     <div class="form-group input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text"> <i class="fa fa-phone"></i> </span>
                          </div>
                                <select class="custom-select"  style="max-width: 70px;">
                                    <option selected="">+91</option>
                                </select>
                            <input name="phone" id='phone' class="form-control" pattern="[7-9]{1}[0-9]{9}" required="required" placeholder="Phone number" type="text">
                     </div> 

                        <!-- form-group// -->
                       

                        <div class="form-group">
                                <textarea name="message" class="form-control" required="required" rows="3" id="message" placeholder="Your Message Here........"></textarea>
                        </div> 

                        <div class="form-group">
                            <button type="submit" class="btn btn-success" name="contact"> Submit  </button>
                            
                        </div>                                                                 
                    </form>
            </article>
        </div> 
    </div> 
          
          
          
</div>

      
    </div>

   <?php include_once("./includes/footer.php"); ?>