 <?php include_once("./includes/header.php"); ?> 
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans:600'><link rel="stylesheet" href="./style1.css">
<body>
<?php include_once('server.php') ?>
<div class="login-wrap">
	<div class="login-html">
		<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>
		<input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>

		<form class="login-form" method="post" action="owner.php">
			<div class="sign-in-htm">
				<div class="group">
					<?php include_once('errors.php'); ?>
					<label for="email" class="label">Email</label>
					<input id="email" type="varchar" class="input" name="email1">
				</div>
				<div class="group">
					<label for="pass" class="label">Password</label>
					<input id="pass" type="password" class="input" data-type="password" name="pass1">
				</div>
				<div class="group">
					<input id="check" type="checkbox" class="check" checked>
					<label for="check"><span class="icon"></span> Keep me Signed in</label>
				</div>
				
				<div class="group">
					<input type="submit" class="button"  name="login_submit" value="Sign In">
				</div>
				<div class="hr"></div>
				<div class="foot-lnk">
					<a href="#">Forgot Password?</a>
				</div>

			</div>

			<div class="sign-up-htm">
				<div class="group">
					<label for="fname" class="label">Firstname</label>
					<input id="fname" type="text" class="input" name="fname">
				</div>
				<div class="group">
					<label for="lname" class="label">Lastname</label>
					<input id="lname" type="text" class="input" name="lname">
				</div>
				<div class="group">
					<label for="mobile" class="label">Mobile</label>
					<input id="mobile" type="bigint" class="input" name="mobile">
				</div>
				<div class="group">
					<label for="email" class="label">Email Address</label>
					<input id="email" type="varchar" class="input" name="email">
				</div>
				<div class="group">
					<label for="pass" class="label">Password</label>
					<input id="pass" type="password" class="input" data-type="password" name="pass">
				</div>
				<div class="group">
					<label for="pass2" class="label"> Confirm Password</label>
					<input id="pass2" type="password" class="input" data-type="password" name="pass2">
				</div>
				
				<div class="group">
					<input type="submit" class="button" name="reg_submit" value="Sign Up">
				</div>
				<div class="hr"></div>
				<div class="foot-lnk">
					<label for="tab-1">Already Member?</a>
				</div>
			</div>
		</form>
	</div>
</div>
</body>

<?php include_once("./includes/footer.php"); ?>

