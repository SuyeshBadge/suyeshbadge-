
<footer>
    <div class="container">
    	<div class="row">
     
      <div class="col-xs-12 col-md-4 col-lg-4">
        <h2>Quick Access</h2>
     	<P><a href="index.php">Home</a></P>
     	<P><a href="About.php">About Us</a></P>
     	<P><a href="room.php">Rooms</a></P>
     	<P><a href="owner.php">Owner</a></P>
     	<P><a href="contact.php">Contact Us</a></P>
      </div>
		
      	<div class="col-xs-12 col-md-4 col-lg-4 map">
      	<h2>Join Us Socially</h2>
	<div class="hidden-sm hidden-md hidden-lg">
        <div class="social-icons pull-left">
          <ul>
            <li><a href="#" target="_blank"><i class="fa fa-facebook"></i></a></li>
            
            <li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#" target="_blank"><i class="fa fa-instagram"></i></a></li>
          </ul>
        </div>
        <div class="clearfix"></div>
   	</div>
        </div>
            <div class="col-xs-12 col-md-4 col-lg-4 map">
   		
        <h2 class="camploc">Headquaters</h2>
    	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7297.938647788302!2d77.75472242884454!3d20.962491312338344!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd6a3483416f1fd%3A0x966a18b6ebac5ed!2sKathora%20Naka%2C%20Siddhivinayak%20Nagar%2C%20Amravati%2C%20Maharashtra%20444604!5e0!3m2!1sen!2sin!4v1576842465296!5m2!1sen!2sin" width="250" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
    	</div>

    	</div>

    </div>
  </footer>
  <div class="copyright">
      <p>&copy; 2020 TENANTBUDDY. All Rights Reserved. Design and Developed By TenantBuddy.</p>
  </div>
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/myjs.js"></script>

</body>
</html>