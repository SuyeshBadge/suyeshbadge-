<link rel="stylesheet" type="text/css" href="styledash.css">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
<!-- ******************************************************************* -->

<div class="wrapper d-flex align-items-stretch">
      <nav id="sidebar" class="active">
        
        <ul class="list-unstyled components mb-5">
          <li class="active">
            <a href="dash.php"><span class="fa fa-home"></span> Rooms</a>
          </li>
           <li>
            <a href="newroom.php"><span class="fa fa-sticky-note"></span> Add Rooms</a>
          </li>
          <li>
              <a href="profile.php"><span class="fa fa-user"></span> Profile</a>
          </li>
         
         
        </ul>

       
        
      </nav>

        <!-- Page Content  -->
      <div id="content" class="">
      </div>


