<?php include_once("./includes/header.php"); ?> 
<link rel="stylesheet" type="text/css" href="styledash.css">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
<!-- ******************************************************************* -->

<div class="wrapper d-flex align-items-stretch">
      <nav id="sidebar" class="active">
        <h1><a href="index.html" class="logo">M.</a></h1>
        <ul class="list-unstyled components mb-5">
          <li class="active">
            <a href="#"><span class="fa fa-home"></span> Rooms</a>
          </li>
           <li>
            <a href="#"><span class="fa fa-sticky-note"></span> Add Rooms</a>
          </li>
          <li>
              <a href="#"><span class="fa fa-user"></span> Profile</a>
          </li>
         
         
        </ul>

       
        
      </nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 row news-grids pb-lg-5 mt-3">

        

          <div class="col-lg-4 col-md-12  gal-img mt-lg-4 mt-4">
                    <div class="gal-info">
                        <img src="images/12.jpg" alt="news image" class="img-fluid">
                        <span class="money">&#8377;2000/mo</span>
                        <div class="property-info-list">
                            <div class="detail">
                                <h4 class="title">
                                    Kathora Naka
                                </h4>
                               
                                <ul class="facilities-list clearfix">
                                    <li>
                                        <span class="fa fa-bed"></span> 2 Sharing
                                    </li>
                                    <li>
                                        <span class="fa fa-shower"></span> 1 Bathrooms
                                    </li>
                                    <li>
                                        <span class="fa fa-building-o"></span> Ground Floor
                                    </li>
                                    <li>
                                        <span class="fa fa-mobile"></span>&nbsp; &nbsp; 9987887788
                                    </li>
                                </ul>
                            </div>
                            <div class="footer-properties">
                                <a class="admin" href="#">
                                <span class="fa fa-user"></span> Mr. Malik
                                </a>
                                <span class="year text-right"> 
                                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter1"><span class="fa fa-edit"></span>Edit
                                  </button>
                                </span>

                            </div>
                        </div>
                    </div>
          </div>
       
          <div class="col-lg-4 col-md-12  gal-img mt-lg-4 mt-4">
                    <div class="gal-info">
                        <img src="images/12.jpg" alt="news image" class="img-fluid">
                        <span class="money">&#8377;2000/mo</span>
                        <div class="property-info-list">
                            <div class="detail">
                                <h4 class="title">
                                    Kathora Naka
                                </h4>
                               
                                <ul class="facilities-list clearfix">
                                    <li>
                                        <span class="fa fa-bed"></span> 2 Sharing
                                    </li>
                                    <li>
                                        <span class="fa fa-shower"></span> 1 Bathrooms
                                    </li>
                                    <li>
                                        <span class="fa fa-building-o"></span> Ground Floor
                                    </li>
                                    <li>
                                        <span class="fa fa-mobile"></span>&nbsp; &nbsp; 9987887788
                                    </li>
                                </ul>
                            </div>
                            <div class="footer-properties">
                                <a class="admin" href="#">
                                <span class="fa fa-user"></span> Mr. Malik
                                </a>
                                <span class="year text-right"> 
                                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter1"><span class="fa fa-edit"></span>Edit
                                  </button>
                                </span>

                            </div>
                        </div>
                    </div>
          </div>


    </div>

    </div>

<?php include_once("./includes/footer.php"); ?>