<!DOCTYPE html>
<html>
<head>
	
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="style.css">

<div class="page-wrapper " id="top">
    <header>
 <div class="grad-bar fixed-top"></div>
  
 <nav class="navbar bg-dark fixed-top" style="top: 1%;">
      
     <a href="index.php" ><img src="images/tenant.png" alt="Company Logo"></a>
    <div class="menu-toggle" id="mobile-menu">
      <span class="bar"></span>
      <span class="bar"></span>
      <span class="bar"></span>
    </div>
    <ul class="nav no-search">
      <li class="nav-item "><a href="index.php">Home</a></li>
      <li class="nav-item"><a href="room.php">Rooms</a></li>
      <li class="nav-item"><a href="owner.php">Owner</a></li>
      <li class="nav-item"><a href="about.php">About</a></li>
      <li class="nav-item"><a href="contact.php">Contact Us</a></li>
      
    </ul>
  </nav>

    </header>
</div>  
  </head>
  <body>