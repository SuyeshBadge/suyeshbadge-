 <?php include_once("./includes/header.php"); ?> 
 <?php include_once("./includes/sidebar.php"); ?> 

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- maps  tags-->
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <link rel="stylesheet" href="css/font-awesome.min.css">
   <script src="js/jquery.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="PlacePicker.js"></script>

    <!-- Title Page-->
    <title>TenantBuddy</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>

<body>
    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading">
                    <h2 class="title">Room Registration Form</h2>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="form-row m-b-55">
                            <div class="name">Name</div>
                            <div class="value">
                                <div class="row row-space">
                                    <div class="col-5">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="first_name">
                                            <label class="label--desc">first name</label>
                                        </div>
                                    </div>
                                    <div class="col-5">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="last_name">
                                            <label class="label--desc">last name</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row ">
                            <div class="name">Phone</div>
                            <div class="value">
                                <div class="input-group ">
                                    <input class="input--style-5" type="text" name="phone" pattern="[7-9]{1}[0-9]{9}" required="required" placeholder="Without area code">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-row m-b-55">
                            <div class="name">Room is</div>
                            <div class="value">
                                <div class="row row-refine">
                                    <div class="col-3">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="sharing" pattern="[0-9]" required="required" placeholder="0-5">
                                            <label class="label--desc">Sharing</label>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="floor" pattern="[0-9]" required="required" placeholder="0-8">
                                            <label class="label--desc">Floor</label>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="bathroom" pattern="[0-9]" required="required" placeholder="0-3">
                                            <label class="label--desc">Bathroom</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Area</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select name="subject">
                                            <option disabled="disabled" selected="selected">Choose Area</option>
                                            <option>Kathora Sq.</option>
                                            <option>GadgeNagar</option>
                                            <option>Sai Nagar</option>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="form-row ">
                            <div class="name">Price</div>
                            <div class="value">
                                <div class="input-group ">
                                    <input class="input--style-5" type="text" name="price" pattern="[0-9]" required="required" placeholder="In Rs.">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-row ">
                            <div class="name">Location</div>
                            <div class="value">
                                <div class="input-group ">
                                     <label for="inputEmail" class="sr-only"></label>
                                    <input type="email" id="pickup_country" class="input--style-5" placeholder="Address"  >
                                </div>
                            </div>
                        </div>

                        <div class="form-row p-t-20">
                            <label class="label label--block">Room is only for?</label>
                            <div class="p-t-15">
                                <label class="radio-container m-r-55">Boys
                                    <input type="radio" checked="checked" name="exist">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radio-container m-r-55">Girls
                                    <input type="radio" name="exist">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radio-container m-r-55">Both Boys & Girls
                                    <input type="radio" name="exist">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                        </div>
                        <div>
                            <button class="btn btn--radius-2 btn--red" type="submit">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>
    
 <!-- maps JS-->
        <script type="text/javascript">
    $(document).ready(function(){
        $("#pickup_country").PlacePicker({
            btnClass:"btn btn-xs btn-default",
            key:"AIzaSyAEFLuCxU99kLoW2NB7_iQesxPuYaNSwiM",
            center: {lat: 17.6868, lng: 83.2185},
            success:function(data,address){
                //data contains address elements and
                //address conatins you searched text
                //Your logic here
                $("#pickup_country").val(data.formatted_address);
            }
        });
    });
</script>

    <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<?php include_once("./includes/footer.php"); ?>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->