<?php include_once("./includes/header.php"); ?>
  

    
    <div class="image-aboutus-banner" id="about">
   <div class="container">
    <div class="row">
        <div class="col-md-12 text-center">
         <h1 class="lg-text">About Us</h1>
         <p class="image-aboutus-para pt-4" style="font-family:  cursive;">We are here to give seamless access to the affordable rooms for the needy peoples. The name of the company is “TENANTBUDDY”. This is important because the people like students and bachelors always need to find Rooms by going Door to Door for searching of rooms.
We  will let the peoples find all the available room in their nearby area at an affordable price range on their Mobile phone or computer. Our  main focus is on those peoples who are outsider for that local area and are less known about the place.
</p>
       </div>
    </div>
</div>
    </div>

    <?php include_once("./includes/footer.php"); ?>