<?php include_once("./includes/header.php"); ?>
  

    

<div class="container-fluid">  
  
      
       
        
        <!-- portfolio -->
        <section class="portfolio-flyer py-5" id="room">
        <div class="container-fluid pt-lg-3 pb-md-5">
            <h3 class="tittle  text-center my-lg-5 my-3"><span class="sub-tittle"> </span>Stunning Rooms</h3>

            <div class="row news-grids pb-lg-5 mt-3">
              
                    <div class="col-lg-4 col-md-12  gal-img mt-lg-4 mt-4">
                    <div class="gal-info">
                        <img src="images/12.jpg" alt="news image" class="img-fluid">
                        <span class="money">&#8377;2000/mo</span>
                        <div class="property-info-list">
                            <div class="detail">
                                <h4 class="title">
                                    Kathora Naka
                                </h4>
                               
                                <ul class="facilities-list clearfix">
                                    <li>
                                        <span class="fa fa-bed"></span> 2 Sharing
                                    </li>
                                    <li>
                                        <span class="fa fa-shower"></span> 1 Bathrooms
                                    </li>
                                    <li>
                                        <span class="fa fa-building-o"></span> Ground Floor
                                    </li>
                                    <li>
                                        <span class="fa fa-mobile"></span>&nbsp; &nbsp; 9987887788
                                    </li>
                                </ul>
                            </div>
                            <div class="footer-properties">
                                <a class="admin" href="#">
                                <span class="fa fa-user"></span> Mr. Malik
                            </a>
                                <span class="year text-right"> <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter1"><span class="fa fa-map-marker"></span>Locate
</button></span>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12 gal-img mt-lg-4 mt-4">
                    <div class="gal-info">
                        <img src="images/11.jpg" alt="news image" class="img-fluid">
                        <span class="money">&#8377;1500/mo</span>
                        <div class="property-info-list">
                            <div class="detail">
                                <h4 class="title">
                                    Sai Nagar
                                </h4>
                                
                                <ul class="facilities-list clearfix">
                                    <li>
                                        <span class="fa fa-bed"></span> 3 Sharing
                                    </li>
                                    <li>
                                        <span class="fa fa-shower"></span> 1 Bathrooms
                                    </li>
                                    <li>
                                        <span class="fa fa-building-o"></span> First Floor
                                    </li>
                                    <li>
                                        <span class="fa fa-mobile"></span>&nbsp; &nbsp;9956556823
                                    </li>
                                </ul>
                            </div>
                            <div class="footer-properties">
                                <a class="admin" href="#">
                                <span class="fa fa-user"></span> Mr. Shaikh
                            </a>
                               <span class="year text-right"> <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter2"><span class="fa fa-map-marker"></span>Locate
</button></span>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12 gal-img mt-lg-4 mt-4">
                    <div class="gal-info">
                        <img src="images/13.jpg" alt="news image" class="img-fluid">
                        <span class="money">&#8377;3000/mo</span>
                        <div class="property-info-list">
                            <div class="detail">
                                <h4 class="title">
                                   Gadge Nagar
                                </h4>
                               
                                <ul class="facilities-list clearfix">
                                    <li>
                                        <span class="fa fa-bed"></span> 3 Sharing
                                    </li>
                                    <li>
                                        <span class="fa fa-shower"></span> 2 Bathrooms
                                    </li>
                                    <li>
                                        <span class="fa fa-building-o"></span> Ground Floor
                                    </li>
                                    <li>
                                        <span class="fa fa-mobile"></span>&nbsp;&nbsp; 9987887788
                                    </li>
                                </ul>
                            </div>
                            <div class="footer-properties">
                                <a class="admin" href="#">
                                <span class="fa fa-user"></span> Mr. Dike   
                            </a>
                                <span class="year text-right"> <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter3"><span class="fa fa-map-marker"></span>Locate
</button></span>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- Modal -->
<div class="modal fade" id="exampleModalCenter3" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle3" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle3">Gadge Nagar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14904.317509438222!2d77.75846477877039!3d20.949327226661712!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd6a3678741fa39%3A0x396dc49044af12c7!2sGade%20Nagar%2C%20Amravati%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1576905812756!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
      </div>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="exampleModalCenter2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle2" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle2">Sai Nagar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29818.202545454365!2d77.71604337539218!3d20.90124015831103!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd6bb2b898fe3d1%3A0xf953b51392c19e74!2sSai%20Nagar%2C%20Amravati%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1576906474148!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
      </div>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="exampleModalCenter1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle1">Kathora Naka</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1862.8885056413228!2d77.75516065808155!3d20.961468246508748!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd6a3483416f1fd%3A0x966a18b6ebac5ed!2sKathora%20Naka%2C%20Siddhivinayak%20Nagar%2C%20Amravati%2C%20Maharashtra%20444604!5e0!3m2!1sen!2sin!4v1576906362919!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
      </div>
      </div>
    </div>
  </div>
</div>
     <?php include_once("./includes/footer.php"); ?>