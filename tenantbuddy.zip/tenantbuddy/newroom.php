 <?php include_once("./includes/header.php"); ?> 
 <?php include_once("./includes/sidebar.php"); ?> 
 <?php include_once("newroomdb.php"); ?> 
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- maps  tags-->

    <!-- Title Page--> 
    <title>TenantBuddy || Add Room</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>

<body>
    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading">
                    <h2 class="title">Room Registration Form</h2>
                </div>
                <div class="card-body">
                    <form method="POST" action="newroom.php">
                        <div class="form-row m-b-55">
                            <div class="name">Name</div>
                            <div class="value">
                                <div class="row row-space">
                                    <div class="col-5">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="fname">
                                            <label class="label--desc">first name</label>
                                        </div>
                                    </div>
                                    <div class="col-5">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="lname">
                                            <label class="label--desc">last name</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row ">
                            <div class="name">Phone</div>
                            <div class="value">
                                <div class="input-group ">
                                    <input class="input--style-5" type="text" name="mobile" pattern="[7-9]{1}[0-9]{9}" required="required" placeholder="Without area code">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-row m-b-55">
                            <div class="name">Room is</div>
                            <div class="value">
                                <div class="row row-refine">
                                    <div class="col-3">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="sharing" pattern="[0-9]" required="required" placeholder="0-5">
                                            <label class="label--desc">Sharing</label>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="floor"  required="required" placeholder="Ground,1-8">
                                            <label class="label--desc">Floor</label>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="bathroom" pattern="[0-9]" required="required" placeholder="0-3">
                                            <label class="label--desc">Bathroom</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Area</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select name="area">
                                            <option disabled="disabled" selected="selected">Choose Area</option>
                                            <option>Kathora Sq.</option>
                                            <option>GadgeNagar</option>
                                            <option>Sai Nagar</option>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="form-row ">
                            <div class="name">Price</div>
                            <div class="value">
                                <div class="input-group ">
                                    <input class="input--style-5" type="text" name="price"  required="required" placeholder="In Indian Rs.">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-row ">
                            <div class="name">Address</div>
                            <div class="value">
                                <div class="input-group ">
                                    <input class="input--style-5" type="text" name="location"  required="required" placeholder="Full Address">
                                </div>
                            </div>
                        </div>

                      
                        <div>
                            <button class="btn btn--radius-2 btn--red" type="submit" name="add">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>
    
 <!-- maps JS-->
     

<?php include_once("./includes/footer.php"); ?>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->