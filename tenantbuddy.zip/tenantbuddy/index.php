<?php include_once("./includes/header.php"); ?>
  
     
<div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
        <img src="images/3338.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-md-block">
          <h5><span class="entry"></span></h5>
      </div>
    </div>
  </div>
</div>
    
 
  <div class="container-fluid">  
       
       
        
 
    <div class="row mgtop"  id="test">

        <div class="col-md-12 test1">
            
            <div class="cal">   
                <h1>Testimonials</h1>
            </div>          
            <div id="myCarousel" class="carousel carouseln slide" data-ride="carousel">
                <!-- Carousel indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                    <li data-target="#myCarousel" data-slide-to="2"></li>
                </ol>   
                <!-- Wrapper for carousel items -->
                <div class="carousel-inner">
                    <div class="item carousel-item active">
                        <div class="img-box"><img src="images/avatarm.png" alt=""></div>
                        <p class="testimonial">I am Sarveshkumar, my friend told me about this website , this website helped me alot  in finding the rooms near me. 
</p>
                        <p class="overview"><b>Sarveshkumar</b></p>
                    </div>
                    <div class="item carousel-item">
                        <div class="img-box"><img src="images/avatarm.png" alt=""></div>
                        <p class="testimonial">I have got a genuine and very quick response from the site. I am very happy with service of Tenantbuddy.org owner plans.</p>
                        <p class="overview"><b>Dushyant Tupkar</b></p>
                    </div>
                    <div class="item carousel-item">
                        <div class="img-box"><img src="images/avatarf.png" alt=""></div>
                        <p class="testimonial">Excellent service and an equally involved team. I got a good deal on my property.</p>
                        <p class="overview"><b>Aishwarya Patil</b></p>
                    </div>
                </div>
                <!-- Carousel controls -->
                <a class="carousel-control carousel-controln left carousel-control-prev" href="#myCarousel" data-slide="prev">
                    <i class="fa fa-angle-left"></i>
                </a>
                <a class="carousel-control carousel-controln right carousel-control-next" href="#myCarousel" data-slide="next">
                    <i class="fa fa-angle-right"></i>
                </a>
            </div>
    </div>
<!-----------------------------------TESTI CLOSES------------------------------------>

</div><!--ROw CLOSES-->

        
    </div>
      
  
</div>





<script src='https://cdnjs.cloudflare.com/ajax/libs/typed.js/1.1.7/typed.min.js'></script>





<script src='https://cdnjs.cloudflare.com/ajax/libs/typed.js/1.1.7/typed.min.js'></script>

<?php include_once("./includes/footer.php"); ?>