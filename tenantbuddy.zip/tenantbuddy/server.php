<?php
session_start();

// initializing variables
$user ="";
$fname ="";
$lname ="";
$email = "";
$mobile = "";

$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'tenantbuddy');

// REGISTER USER
if (isset($_POST['reg_submit'])) {
  // receive all input values from the form
  $fname = mysqli_real_escape_string($db, $_POST['fname']);
  $lname = mysqli_real_escape_string($db, $_POST['lname']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $mobile = mysqli_real_escape_string($db, $_POST['mobile']);
  $pass = mysqli_real_escape_string($db, $_POST['pass']);
  $pass2 = mysqli_real_escape_string($db, $_POST['pass2']);

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($pass)) { array_push($errors, "Password is required"); }
  if ($pass != $pass2) {
	array_push($errors, "The two passwords do not match");
  }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM registration WHERE  email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
 
    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }
  

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {

  	$query = "INSERT INTO registration (fname,lname,email,mobile,pass) 
  			  VALUES('$fname','$lname', '$email','$mobile','$pass')";
  	mysqli_query($db, $query);
  	$_SESSION['fname'] = $fname;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: index.php');
  }
}

// ... 
// ... 

// LOGIN USER
if (isset($_POST['login_submit'])) {
  $email = mysqli_real_escape_string($db, $_POST['email1']);

  $pass = mysqli_real_escape_string($db, $_POST['pass1']);

  if (empty($email)) {
    array_push($errors, "Email is required");
  }
  if (empty($pass)) {
    array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
    $query = "SELECT * FROM registration WHERE email='$email' AND pass='$pass' ";
    $results = mysqli_query($db, $query);
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['fname'] = $fname;
      $_SESSION['success'] = "You are now logged in";
      header('location: dash.php');
    }else {
      array_push($errors, "Wrong username/password combination");
    }
  }
}

?>