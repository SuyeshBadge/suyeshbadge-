<?php
session_start();

 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'tenantbuddy');

// REGISTER USER
if (isset($_POST['add'])) {
  // receive all input values from the form
  $fname = mysqli_real_escape_string($db, $_POST['fname']);
  $lname = mysqli_real_escape_string($db, $_POST['lname']);
  $mobile = mysqli_real_escape_string($db, $_POST['mobile']);
  $area = mysqli_real_escape_string($db, $_POST['area']);
  $sharing = mysqli_real_escape_string($db, $_POST['sharing']);
  $floor = mysqli_real_escape_string($db, $_POST['floor']);
  $bathroom = mysqli_real_escape_string($db, $_POST['bathroom']);
  $price = mysqli_real_escape_string($db, $_POST['price']);
  $location = mysqli_real_escape_string($db, $_POST['location']);
  


  // Finally, register user if there are no errors in the form
   {

  	$query = "INSERT INTO room (fname,lname,mobile,area,sharing,floor,bathroom,price,location) 
  			  VALUES('$fname','$lname', '$mobile','$area','$sharing','$floor','$bathroom','$price','$location')";
  	mysqli_query($db, $query);
  	$_SESSION['fname'] = $fname;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: newroom.php');
  }
}

// ... 
// ... 




?>