<?php
session_start();




// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'tenantbuddy');

// contact
if (isset($_POST['contact']))
{
  // receive all input values from the form
  $name = mysqli_real_escape_string($db, $_POST['name']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $phone = mysqli_real_escape_string($db, $_POST['phone']);
  $message = mysqli_real_escape_string($db, $_POST['message']);
  

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  	$query = "INSERT INTO feedback (name, email, phone,message) 
  			  VALUES('$name', '$email', '$phone','$message')";
  	mysqli_query($db, $query);
    $_SESSION['name'] = $name;
    $_SESSION['success'] = "You are now logged in";

    header('location: contact.php');
    
  //give pop up that orm submitted successfully
  
}
?>